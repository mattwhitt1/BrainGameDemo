using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class Box : MonoBehaviour
{
    [Header("Set in Inspector")]
    public float[] speed = { 1f, 1.5f, 2f };
    public int health = 10;

    private BoundsCheck bndCheck;

    private void Awake()
    {
        bndCheck = GetComponent<BoundsCheck>();
    }

    public Vector3 pos
    {
        get
        {
            return this.transform.position;
        }
        set
        {
            this.transform.position = value;
        }
    }

    // Update is called once per frame
    void Update()
    {
        Move();

        if(bndCheck!=null && bndCheck.offDown)
        {
            Destroy(gameObject);
            Score.score -= 50;
        }
        
    }

    public void Move()
    {
        Vector3 tempPos = pos;
        tempPos.y -= speed[Main.S.index] * Time.deltaTime;
        pos = tempPos;
    }

    private void OnCollisionEnter(Collision collision)
    {
        GameObject otherGo = collision.gameObject;

        if (otherGo.tag == "Projectile")
        {
            health -= otherGo.GetComponent<Projectile>().value;
            Text text = GetComponentInChildren<Text>();

            text.text = health.ToString();

            Destroy(otherGo);

            if (health == 0)
            {
                Destroy(gameObject);
                Score.score += 100;
            }
            else
            {
                if (health < 0)
                {
                    Destroy(gameObject);
                    Score.score -= 50;
                }
            }
        }
    }
}
