using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class numOfBall : MonoBehaviour
{
    static public numOfBall S;
    public int oneBall = 50;
    public int twoBall = 50;
    public int thirdBall = 50;
    Text shotText;

    private void Awake()
    {
        S = this;
        shotText = GetComponent<Text>();
        shotText.text = "Shots Left: 1s " + oneBall + " 2s " + twoBall + " 3s " + thirdBall;
    }

    public void decreaseOne()
    {
        oneBall--;
        shotText.text = "Shots Left: 1s " + oneBall + " 2s " + twoBall + " 3s " + thirdBall;
    }

    public void decreaseTwo()
    {
        twoBall--;
        shotText.text = "Shots Left: 1s " + oneBall + " 2s " + twoBall + " 3s " + thirdBall;
    }

    public void decreaseThird()
    {
        thirdBall--;
        shotText.text = "Shots Left: 1s " + oneBall + " 2s " + twoBall + " 3s " + thirdBall;
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
