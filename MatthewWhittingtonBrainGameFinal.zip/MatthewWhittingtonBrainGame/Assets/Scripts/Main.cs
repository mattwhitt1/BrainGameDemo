using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Main : MonoBehaviour
{
    static public Main S;

    [Header("Set in Inspector")]
    public GameObject boxPrefab;
    public float[] boxSpawnPerSecond = { .5f, .4f, .3f };
    public float boxDefaultPadding = 1.5f;
    public int[] upperRange = { 10, 12, 15 };
    public float second = 180;

    public int index = 0;
    Text timeRemainingText;
    int secondTimeRemaining = 0;
    float minuteTimeRemaining = 0;
    private BoundsCheck bndCheck;

    private void Awake()
    {

        S = this;

        bndCheck = GetComponent<BoundsCheck>();

        GameObject textobject = GameObject.Find("TimeRemaining");
        timeRemainingText = textobject.GetComponent<Text>();
        minuteTimeRemaining = second / 60;

        timeRemainingText.text = "Time Remaining: " + minuteTimeRemaining + ":" + secondTimeRemaining;
        //Debug.Log(boxSpawnPerSecond[1]);

        Invoke("SpawnBox", 1f / boxSpawnPerSecond[index]);
    }

    private void Update()
    {
        second -= Time.deltaTime;
        minuteTimeRemaining = Mathf.FloorToInt(second / 60);
        secondTimeRemaining = Mathf.FloorToInt(second % 60);

        //secondTimeRemaining = second - (int)(Time.time - initialTime);

        timeRemainingText.text = "Time Remaining: ";
        timeRemainingText.text += string.Format("{0:00}:{1:00}", minuteTimeRemaining, secondTimeRemaining);
        
        if (second <= 0)
        {
            SceneManager.LoadScene("GameOver");
        }
    }

    public void SpawnBox()
    {
        GameObject go = Instantiate<GameObject>(boxPrefab);
        float boxPadding = boxDefaultPadding;
        if (go.GetComponent<BoundsCheck>() != null)
        {
            boxPadding = Mathf.Abs(go.GetComponent<BoundsCheck>().radius);
        }

        go.GetComponent<Box>().health = Random.Range(1, upperRange[index]);
        Text text = go.GetComponentInChildren<Text>();
        text.text = go.GetComponent<Box>().health.ToString();


        Vector3 pos = Vector3.zero;
        float xMin = -bndCheck.camWidth + boxPadding;
        float xMax = bndCheck.camWidth - boxPadding;
        pos.x = Random.Range(xMin, xMax);
        pos.y = bndCheck.camHeight + boxPadding;
        go.transform.position = pos;

        Invoke("SpawnBox", 1f / boxSpawnPerSecond[index]);
    }
}
