using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Score : MonoBehaviour
{
    static public int score=100;
    static public int HighScore = 100;
    static public int HighestLevel = 1;

    public int level = 1;
    Text scoreText;
    Text levelText;
    Text highScoreText;

    // Start is called before the first frame update
    void Start()
    {
        scoreText = GetComponent<Text>();
        scoreText.text = "Score: 0";
        score = 0;

        GameObject levelTextObject = GameObject.Find("Level");
        levelText = levelTextObject.GetComponent<Text>();

        GameObject highScoreObject = GameObject.Find("HighScore");
        highScoreText = highScoreObject.GetComponent<Text>();

        highScoreText.text = "Highest Reach- L:1 HS:00";

        if (PlayerPrefs.HasKey("HighScore"))
        {
            HighScore = PlayerPrefs.GetInt("HighScore");
        }

        if (PlayerPrefs.HasKey("HighestLevel"))
        {
            HighestLevel = PlayerPrefs.GetInt("HighestLevel");
        }

        PlayerPrefs.SetInt("HighScore", HighScore);
        PlayerPrefs.SetInt("HighestLevel", HighestLevel);

    }

    // Update is called once per frame
    void Update()
    {
        scoreText.text = "Score: " + score;

        if (score < 0)
        {
            SceneManager.LoadScene("GameOver");
        }

        if (score == 1000)
        {
            Main.S.index=1;
            level = 2;
            levelText.text = "Level 2";

        }
        else
        {
            if (score < 1000)
            {
                Main.S.index = 0;
                level = 1;
                levelText.text = "Level 1";
            }
        }

        if (score >= 3000)
        {
            Main.S.index = 2;
            level = 3;
            levelText.text = "Level 3";
        }
        else
        {
            if (score < 3000 && score > 1000)
            {
                Main.S.index = 1;
                level = 2;
                levelText.text = "Level 2";
            }
        }

        if (score > HighScore)
        {
            HighScore = score;
        }
        if (level > HighestLevel)
        {
            HighestLevel = level;
        }

        if (HighScore > PlayerPrefs.GetInt("HighScore"))
        {

            PlayerPrefs.SetInt("HighScore", HighScore);
        }
        if (level > PlayerPrefs.GetInt("HighestLevel"))
        {

            PlayerPrefs.SetInt("HighestLevel", HighestLevel);
        }

        highScoreText.text = "Highest Reach- L:" + HighestLevel + "HS:" + HighScore;

    }
}
