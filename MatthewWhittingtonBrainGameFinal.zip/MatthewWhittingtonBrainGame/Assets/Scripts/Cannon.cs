using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Cannon : MonoBehaviour
{
    [Header("Set in Inspector")]
    public GameObject projectilePrefab;
    public float projectileSpeed = 40f;
    public float speed = 5f;

    public float angle;
    private numOfBall numBall;

    // Update is called once per frame
    void Update()
    {
        Move();

        if (Input.GetKeyDown(KeyCode.S) && numOfBall.S.oneBall > 0)
        {
            numOfBall.S.decreaseOne();
            Fire(1);
        }

        if (Input.GetKeyDown(KeyCode.D) && numOfBall.S.twoBall > 0)
        {
            numOfBall.S.decreaseTwo();
            Fire(2);
        }

        if (Input.GetKeyDown(KeyCode.F) && numOfBall.S.thirdBall > 0)
        {
            numOfBall.S.decreaseThird();
            Fire(3);
        }
    }

    void Fire(int value)
    {
        GameObject projGo = Instantiate<GameObject>(projectilePrefab);
        projGo.transform.position = Vector2.MoveTowards(transform.position,Camera.main.ScreenToWorldPoint(Input.mousePosition),speed*Time.deltaTime);
        projGo.GetComponent<Projectile>().value = value;
        Rigidbody rigidB = projGo.GetComponent<Rigidbody>();
        rigidB.velocity = (Camera.main.ScreenToWorldPoint(Input.mousePosition)-transform.position).normalized * speed;
        projGo.transform.Rotate(new Vector3(0, 0, 1), angle);
    }

    void Move()
    {
        Vector2 mouseInput = Camera.main.ScreenToWorldPoint(Input.mousePosition) - transform.position;

        angle = (Mathf.Atan2(mouseInput.y, mouseInput.x) * Mathf.Rad2Deg) - 90;

        Quaternion rotation = Quaternion.AngleAxis(angle, Vector3.forward);

        if (Mathf.Abs(angle) <= 90)
        {
            transform.rotation = Quaternion.Slerp(transform.rotation, rotation, speed * Time.deltaTime);
        }
    }
}
