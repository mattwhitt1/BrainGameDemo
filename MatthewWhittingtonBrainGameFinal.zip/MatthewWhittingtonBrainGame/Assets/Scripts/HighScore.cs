using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HighScore : MonoBehaviour
{
    Text highScoreText;
    // Start is called before the first frame update
    void Start()
    {
        highScoreText = GetComponent<Text>();

        if (Score.score == Score.HighScore)
        {
            highScoreText.text = "New Highscore= L: " + Score.HighestLevel + " Highscore: " + Score.HighScore;
        }
        else
        {
            highScoreText.text = "Highscore= L: " + Score.HighestLevel + " Highscore: " + Score.HighScore;
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
